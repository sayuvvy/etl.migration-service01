# IDMC Export Package: Product_Merchant_DW_ETL

## Package Overview
**Name:** Product_Merchant_DW_ETL  
**Type:** Medium Complexity IDMC Transformation ETL  
**Created:** 2026-03-27  
**Description:** End-to-end ETL pipeline that extracts Product and Merchant data from two separate SQL Server databases, enriches via REST API, applies data quality rules, performs aggregations, and loads to a Data Warehouse fact table — orchestrated via a Taskflow with email notifications.

---

## Export Zip File Structure

```
01IDMC_EXPORT/
├── exportMetadata.v2                          # Root manifest (object registry & dependencies)
├── Connections/
│   ├── CONN_SQLServer_Product.json            # SQL Server – Product source DB
│   ├── CONN_SQLServer_Merchant.json           # SQL Server – Merchant source DB (different server)
│   ├── CONN_DW_Target.json                    # SQL Server – Data Warehouse target
│   ├── CONN_REST_InventoryAPI.json            # REST API – DataMock Inventory endpoint
│   └── CONN_Email_Notification.json           # Email/SMTP – Pipeline notifications
├── Sources/
│   ├── SQ_Product.json                        # Physical data object – Product (10 fields)
│   ├── SQ_Merchant.json                       # Physical data object – Merchant (10 fields)
│   └── REST_SRC_InventoryAPI.json             # REST API source definition
├── Targets/
│   └── TGT_DW_ProductMerchant.json            # Physical data object – DW fact table
├── Mappings/
│   └── m_Product_Merchant_DW_Load.json        # Main mapping with all transformations
├── MappingTasks/
│   └── mt_Product_Merchant_DW_Load.json       # Mapping task with pre-session SQL & params
├── Taskflows/
│   └── tf_Product_Merchant_Pipeline.json      # Orchestration taskflow with branching & email
├── DataQuality/
│   └── dq_NullCheck_Dedup_Rule.json           # DQ rules: null checks & deduplication
├── Parameters/
│   └── parameterFile.json                     # Input parameters & connection credentials
├── RuntimeConfig/
│   └── runtimeConfig.json                     # Session properties & performance tuning
├── Permissions/
│   └── objectPermissions.json                 # Access control for exported objects
├── Schedules/
│   └── schedule.json                          # Daily recurring schedule definition
└── README.md                                  # This file
```

---

## Requirement Traceability Matrix

| # | Requirement | Implementation | File(s) |
|---|-------------|---------------|---------|
| 1 | Product data – 10 fields, date column, quantity=0, SQL Server | SQ_Product source with 10 fields incl. `CreatedDate`/`ModifiedDate` (date), `QuantityOnHand` (initialized to 0) | `Sources/SQ_Product.json`, `Mappings/...` |
| 1 | Merchant data – 10 fields, different SQL Server | SQ_Merchant source with 10 fields from CONN_SQLServer_Merchant | `Sources/SQ_Merchant.json`, `Connections/...` |
| 1 | Combined to DW table | Joiner + Union → Target `dw.FACT_Product_Merchant_Summary` | `Mappings/...`, `Targets/...` |
| 2 | Joiner transformation | `JNR_Product_Merchant` – Normal join on `SupplierID = MerchantID` | `Mappings/...` |
| 2 | Lookup transformation | `LKP_Inventory_API` – Lookup against REST API response | `Mappings/...` |
| 2 | Union transformation | `UNI_CombinedOutput` – Union All of 4 streams | `Mappings/...` |
| 2 | 3 Aggregators | `AGG_ByCategory`, `AGG_ByRegion`, `AGG_ByTier` | `Mappings/...` |
| 2 | 2 Complex Expressions | `EXP_Product_Enrich` (tier, price adjustment, freshness), `EXP_Merchant_Enrich` (risk score, region grouping) | `Mappings/...` |
| 3 | Conditional branching | `RTR_ConditionalBranch` Router with 4 groups + Taskflow Decision tasks | `Mappings/...`, `Taskflows/...` |
| 4 | FromDate, ToDate params | `$$FromDate`, `$$ToDate` defined in Mapping, MappingTask, and Taskflow | `Parameters/...`, all 3 objects |
| 5 | Email notification | 3 email tasks: Success, Warning (0 rows), Failure — via CONN_Email_Notification | `Taskflows/...`, `Connections/...` |
| 6 | Null check DQ rules | 6 null check rules across Product & Merchant (reject/default) | `DataQuality/...`, `Mappings/...` |
| 6 | Deduplication DQ rules | 2 dedup rules: Product by ProductID, Merchant by MerchantID | `DataQuality/...`, `Mappings/...` |
| 7 | API call for inventory | REST source calling `https://api.datamock.dev/v1/product?quantity=1&category=Electronics+&+Technology&condition=Used+-+Acceptable&exclude=sku`, `api_InStock` → `InStockStatus` via Lookup | `Sources/REST_SRC_InventoryAPI.json`, `Mappings/...` |
| 8 | Pre-session SQL command | Staging cleanup, ETL run log insert, target backup, update statistics | `MappingTasks/...` |

---

## Summary of Steps & Decisions

### Step 1: Connections (5 connections created)
- **Decision:** Created two *separate* SQL Server connections for Product and Merchant to satisfy the "different SQL Server connection" requirement.
- **Decision:** Used parameterized credentials (`${param.*}`) for all connections to support environment promotion (Dev → QA → Prod).
- **Decision:** Added a REST V2 connection for the DataMock inventory API (no authentication required).
- **Decision:** Added an Email/SMTP connection for pipeline notification tasks.

### Step 2: Source Definitions (3 sources)
- **Decision:** Product source includes exactly 10 fields with `CreatedDate` (date column) and `QuantityOnHand` (defaulted to 0 as required).
- **Decision:** Merchant source includes exactly 10 fields from the separate SQL Server connection.
- **Decision:** REST API source maps the full response schema including the `inStock` field.

### Step 3: Mapping Design (15 transformations)
- **Decision:** Applied DQ null checks *early* in the pipeline (immediately after source qualifiers) to reject bad data before any processing.
- **Decision:** Used Sorter transformations with `distinct=true` for deduplication (IDMC-compatible dedup pattern).
- **Complex Expression 1 (`EXP_Product_Enrich`):** Derives 6 output fields including product tier classification (4-level IIF), discounted pricing for discontinued/clearance items, data freshness flagging, and quantity initialization to zero.
- **Complex Expression 2 (`EXP_Merchant_Enrich`):** Derives 5 output fields including multi-factor risk scoring (nested IIF), region macro-grouping (DECODE with IN), active status label, and days-since-registration calculation.
- **Decision:** REST API Lookup (`LKP_Inventory_API`) joins enriched Product data with API response on ProductName to retrieve `api_InStock` as `InStockStatus` and `api_Quantity` for quantity enrichment.
- **Decision:** Joiner uses Normal Join (inner) on `SupplierID = MerchantID` to combine Product and Merchant pipelines.
- **Decision:** Router transformation provides conditional branching with 4 groups: HighValue (premium + low-risk), MediumValue (standard/economy + moderate-risk), LowValue_HighRisk (budget or high-risk), and Default catch-all.
- **3 Aggregators:** Each processes a different router output — by Category, by Region, and by Tier+InStock — ensuring varied aggregation granularity.
- **Union:** Combines all 4 output streams (3 aggregated + 1 default passthrough) into a single target pipeline.

### Step 4: Mapping Task Configuration
- **Decision:** Pre-session SQL performs 4 operations: (1) clean staging table, (2) log ETL run start, (3) create backup of target table, (4) update statistics for optimizer.
- **Decision:** All connection overrides are specified to allow runtime environment switching.
- **Decision:** Error threshold set to 100 rows with recovery enabled.

### Step 5: Taskflow Orchestration
- **Decision:** Two Decision (branching) tasks: (1) validate input date parameters before execution, (2) check row counts after execution.
- **Decision:** Three email notification paths: Success (normal priority), Warning/zero rows (high priority), and Failure (high priority with on-call team).
- **Decision:** Parameter bindings flow from Taskflow → MappingTask → Mapping for `$$FromDate` and `$$ToDate`.

### Step 6: Supporting Files
- **Parameter file:** Centralizes all runtime and connection parameters with secure string types for passwords.
- **Runtime config:** Specifies session properties, caching, parallelism, error handling, and pushdown optimization.
- **Permissions:** Defines role-based access (Developers: full, Operators: read/execute, Admin: full).
- **Schedule:** Daily recurring (Mon–Fri 2:00 AM UTC) with auto-computed incremental date parameters and retry policy.

### Step 7: Export Manifest (`exportMetadata.v2`)
- **Decision:** All 9 primary objects registered with IDs, types, and paths.
- **Decision:** 3 dependencies (2 custom sources + 1 custom target) explicitly declared.

### Medium Complexity Qualification Checklist ✅
- [x] Multiple source systems (2 SQL Server + 1 REST API)
- [x] 5+ transformation types (Source, Expression, Lookup, Joiner, Router, Aggregator, Union, Sorter, Target)
- [x] Complex expression logic (nested IIF, DECODE, date functions)
- [x] Conditional routing/branching
- [x] Data quality rules (null checks + deduplication)
- [x] Parameterized execution (input date range)
- [x] API integration with field mapping
- [x] Pre-session SQL commands
- [x] Error handling and recovery
- [x] Email notifications (success/warning/failure)
- [x] Taskflow orchestration with decision logic
- [x] Multiple aggregation levels
- [x] Performance tuning configuration
